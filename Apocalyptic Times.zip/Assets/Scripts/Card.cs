using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Choice
{
    [TextArea(4, 4)]
    public string decisionDescription;
    public float violenceInfluence;
    public float scienceInfluence;
    public float planetInfluence;
    public float chaosInfluence;
}

[CreateAssetMenu(fileName = "New Card", menuName = "Card")]
public class Card : ScriptableObject
{
    [Header("SUBJECT INFO")]
    public string subjectName;
    public string subjectAge;
    public string subjectOccupation;
    public Sprite subjectPhotograph;
    
    [Header("CARD INFO")]
    [TextArea(6, 6)]
    public string situationDescription;
    public Choice choiceUp;
    public Choice choiceDown;

    

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
