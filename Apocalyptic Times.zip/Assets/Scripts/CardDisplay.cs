using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CardDisplay : MonoBehaviour
{
    public Card card;
    
    [Header("SUBJECT INFO")]
    public TextMeshProUGUI subjectName;
    public TextMeshProUGUI subjectAge;
    public TextMeshProUGUI subjectOccupation;
    public Image subjectPhotograph;
    
    [Header("CARD INFO")]
    public TextMeshProUGUI situationDescription;
    public TextMeshProUGUI choiceUp;
    public TextMeshProUGUI choiceDown;

    private void Awake()
    {
        
    }

    // Start is called before the first frame update
    void Start()
    {
        DisplayCardInfo();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetCardInfo(Card injectedCard)
    {
        card = injectedCard;
    }

    private void DisplayCardInfo()
    {
        subjectName.SetText(card.subjectName);
        subjectAge.SetText(card.subjectAge);
        subjectOccupation.SetText(card.subjectOccupation);
        subjectPhotograph.sprite = card.subjectPhotograph;
        
        situationDescription.SetText(card.situationDescription);
        choiceUp.SetText(card.choiceUp.decisionDescription);
        choiceDown.SetText(card.choiceDown.decisionDescription);
    }
}
