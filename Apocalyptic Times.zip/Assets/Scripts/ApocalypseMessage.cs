using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ApocalypseMessage : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnEnable()
    {
        GetComponent<TextMeshProUGUI>().SetText("Dear employee,\n" +
            "You caused an apocalypse! \n" + 
            "Thank you for your collaboration. Your efforts helped this timeline through " + CardSpawner.instance.spawnedCardsCount + " potential threats! \n" +
            "Unfortunately, you and your timeline will be destroyed. \n" +
            "Take your payment on the way out.");
    }
}
